.. include:: ../AUTHORS.rst
