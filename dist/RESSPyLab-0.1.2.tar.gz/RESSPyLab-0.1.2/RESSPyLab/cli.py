# -*- coding: utf-8 -*-

"""Console script for RESSPyLab."""

import click


@click.command()
def main(args=None):
    """Console script for RESSPyLab."""
    click.echo("Replace this message by putting your code into "
               "RESSPyLab.cli.main")
    click.echo("See click documentation at http://click.pocoo.org/")


if __name__ == "__main__":
    main()
