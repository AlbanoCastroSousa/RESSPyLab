=======
History
=======

0.1.0 (2017-09-01)
------------------

* First release on PyPI.

0.1.4 (2017-10-24)
------------------

* Added Jacobi Preconditioning / Fixed Steihaug-Toint bug
